﻿double num1 = 0, num2 = 0, result = 0; 

Console.Write("Enter your first number: ");
num1 = double.Parse(Console.ReadLine()!);

Console.Write("Enter your second number:  ");
num2 = double.Parse(Console.ReadLine()!);

Console.Write("Enter the result: ");
result = double.Parse(Console.ReadLine()!);

if (num1 + num2 == result && num1 * num2 == result)
{
    Console.WriteLine("Operator: + and *");
}
else if (num1 + num2 == result)
{
    Console.WriteLine("Operator: + ");
}

else if (num1 - num2 == result)
{
    Console.WriteLine("Operator: -");
}

else if (num1 / num2 == result)
{
    Console.WriteLine("Operator: / ");
}

else if (num1 * num2 == result)
{
    Console.WriteLine("Operator: * ");
}
