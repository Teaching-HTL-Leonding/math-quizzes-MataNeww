﻿int reverse, newnumber = 0;
bool stop = false;
Console.Write("Enter a positve number: ");
int num = int.Parse(Console.ReadLine()!);

newnumber = num;
if (num < 10)
{
    Console.WriteLine($"Your number {num} is a Palindrom");
}
else
{
    do
    {
        reverse = num % 10;
        num /= 10;
        reverse *= 10;
        if (newnumber == reverse)
        {
            Console.WriteLine("Your number is a Palindrom");
        }
        else
        {
            Console.WriteLine("Your number is not a Palindrom");
            stop = true;
        }

    } while (num > 10 && !(stop));
}

