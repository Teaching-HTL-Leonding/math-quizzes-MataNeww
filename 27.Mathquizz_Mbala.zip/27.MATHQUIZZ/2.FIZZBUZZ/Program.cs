﻿int num, a, b;

Console.Write("Please enter a number: ");
num = int.Parse(Console.ReadLine()!);

Console.Write("Enter a: ");
a = int.Parse(Console.ReadLine()!);

Console.Write("Enter b: ");
b = int.Parse(Console.ReadLine()!);

for (int i = 1; i < num; i++)
{

     if (i % a == 0 && i % b == 0)
    {
        Console.Write("FizzBuzz ");
    }

    else if (i % a == 0)
    {
        Console.Write("Fizz ");
    }
    else if (i % b == 0)
    {
        Console.Write("Buzz ");
    }
    else Console.Write($"{i} ");
}
