﻿int number = 0, currentnum = 0, result = 0;

Console.Write("Enter number: ");
number = int.Parse(Console.ReadLine()!);

currentnum = number;
Console.Write($"{number} ");
do
{
    if (number % 2 == 0)
    {
        currentnum = number / 2;
        number = currentnum;
        result += number;
        Console.Write($"{number} ");
    }
    else
    {
        currentnum = (number * 3) + 1;
        number = currentnum;
        result += number;
        Console.Write($"{number} ");
    }

} while (number > 1);
